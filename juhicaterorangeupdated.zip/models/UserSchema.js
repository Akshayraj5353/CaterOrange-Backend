// const mongoose = require('mongoose');

// const userSchema = new mongoose.Schema({
//   email: { type: String, required: true, unique: true },
//   password: { type: String, required: true },
// });

// // Create a User model
// const User = mongoose.model('login', userSchema);

// module.exports = User;




const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phoneNumber: { type: String, required: true }, // New field for mobile number
});

// Create a User model
const User = mongoose.model('User', userSchema);

module.exports = User;
